/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package djf.ui;

/**
 *
 * @author rahel
 */
public class Log {
    
    public static void d(Object message){
        System.out.println(message);
    }
    public static void e(Object message){
        System.out.print(message);
    }
}
